export interface EbookTable {
  title: string;
  headers: string[];
  rows: string[][];
  caption?: string;
}

export interface EbookSection {
  heading: string;
  paragraphs: string[];
  steps?: string[];
  exampleBox?: {
    title: string;
    content: string[];
  };
  table?: EbookTable;
}

export interface ChapterPlatform {
  name: string;
  url: string;
  role: string;
  earningRange: string;
  payout: string;
}

export interface ChapterTask {
  title: string;
  objective: string;
  steps: string[];
  estimatedTime: string;
}

export interface EbookChapter {
  id: string;
  number: number;
  title: string;
  subtitle: string;
  pageStart: number;
  pageEnd: number;
  readingTime: string;
  dailyPotential: string;
  image?: {
    src: string;
    alt: string;
    caption: string;
  };
  intro: string[];
  sections: EbookSection[];
  platforms?: ChapterPlatform[];
  mistakes: {
    mistake: string;
    fix: string;
  }[];
  task: ChapterTask;
  videos?: {
    label: string;
    url: string;
  }[];
}

export type SiteCategory =
  | 'Freelancer Brasil'
  | 'Microtarefas e IA'
  | 'Afiliados e Vendas'
  | 'Tradução e Transcrição'
  | 'Empresas Gringas (Dólar)'
  | 'Testes de Apps e Redação';

export interface SiteEntry {
  id: number;
  name: string;
  url: string;
  category: SiteCategory;
  device: 'Celular' | 'Computador' | 'Ambos';
  language: 'Português' | 'Inglês' | 'Português / Inglês';
  payout: string;
  dailyEstimate: string;
  howToStart: string;
}

export interface OutreachScript {
  id: string;
  channel: string;
  title: string;
  context: string;
  message: string;
}

export interface RoutineBlock {
  time: string;
  activity: string;
  focus: string;
  goal: string;
}
